# Kavach ko Real APK banane ka poora process

Maine ek Capacitor project ka **skeleton** taiyaar kar diya hai (ye zip me hai:
`package.json`, `capacitor.config.json`, `firebase.json`, aur `www/index.html`
jo aapki `kavach-app.html` hi hai). Lekin asli APK build karne ke liye Android
SDK + Gradle chahiye — wo is sandbox me possible nahi hai (no internet, no
Android SDK). Isliye ye steps apne computer par chalane honge. Neeche har
cheez exact command ke saath hai.

---

## Zaroori cheezein (ek baar install karein)

1. **Node.js** (v18+) — https://nodejs.org
2. **Android Studio** — https://developer.android.com/studio (isme Android
   SDK + Gradle + an emulator sab already bundled aata hai)
3. **JDK 17** — Android Studio ke saath usually already aata hai

---

## Step 1 — Project ready karein

Zip extract karein, phir terminal me:

```bash
cd kavach-apk
npm install
```

## Step 2 — Android platform add karein

```bash
npx cap add android
npx cap sync android
```

Ye ek `android/` folder banayega — ye asli Android Studio project hai.

## Step 3 — Android Studio me kholein

```bash
npx cap open android
```

Android Studio khulega, Gradle sync hoga (pehli baar 5-10 min lag sakte hain,
internet chahiye kyunki Gradle dependencies download hoti hain).

## Step 4 — Debug APK banayein (testing ke liye, turant install ho jaata hai)

```bash
cd android
./gradlew assembleDebug
```

Output yahan milega:
```
android/app/build/outputs/apk/debug/app-debug.apk
```
Ye file seedhe apne phone me bhej kar install kar sakte hain (Settings me
"install unknown apps" allow karna padega).

## Step 5 — Real/Release APK (Play Store ya sabko bhejne layak, signed)

Android Studio me: **Build → Generate Signed Bundle / APK → APK** → naya
keystore banayein (password yaad rakhein, ye hamesha wahi rehna chahiye
future updates ke liye) → Release build.

Output: `android/app/build/outputs/apk/release/app-release.apk` — yehi asli
distributable APK hai.

---

## ⚠️ Sabse zaroori cheez: Google Sign-In APK ke andar kaam NAHI karega jaise hai

Ye ek Google ki hi security restriction hai, aapke code ki galti nahi:
Google 2021 se kisi bhi embedded WebView (jo Capacitor app ke andar hota hai)
me OAuth popup/redirect **block** kar deta hai — error aayega
`disallowed_useragent`. Isका fix teen tarike se ho sakta hai:

1. **(Sabse aasan)** APK version me Google Sign-In button hata dein, sirf
   Email/Password aur Phone OTP rakhein — ye dono WebView me normally kaam
   karte hain.
2. **(Sahi fix)** Native Google Sign-In plugin use karein —
   `@codetrix-studio/capacitor-google-auth` — jo phone ka native Google
   account picker kholta hai, WebView popup nahi. Isme thoda extra setup
   hai (Google Cloud Console me Android OAuth client + SHA-1 fingerprint
   add karna). Batayein to main ye bhi step-by-step likh doon.
3. Custom Tabs based flow — zyada complex, generally option 2 hi best hai.

Baaki sab (Email/Password signup, Phone OTP, Firestore, Admin dashboard)
APK ke andar Capacitor WebView me bilkul theek chalega, kyunki wo Google
OAuth popup use nahi karte.

## Firebase Authorized domain — APK ke liye

`capacitor.config.json` me maine `"androidScheme": "https"` set kiya hai —
iska matlab app ke andar se Firebase calls `https://localhost` origin se
jaate hain. Firebase Console → Authentication → Settings → Authorized
domains me **`localhost`** already by default present hota hai naye
projects me — check kar lein wo list me hai. Agar nahi hai to add kar dein.

---

## Server/Hosting fast banane ke liye (aapne poocha tha)

Agar aap same HTML ko web par bhi host karna chahte hain (PWA / browser
version), to maine `firebase.json` bana diya hai jisme:
- HTML file **kabhi cache nahi hoti** (`no-cache`) — taaki updates turant
  dikhein
- JS/CSS/images **1 saal tak cache** hoti hain browser me — dusri baar
  khulne par instant load
- Firebase Hosting khud hi ek global CDN hai aur automatic gzip/brotli
  compression karta hai — isliye extra kuch set karne ki zaroorat nahi.

Deploy karne ke liye:
```bash
npm install -g firebase-tools
firebase login
firebase init hosting   # existing kavach-86f4a project select karein, public dir = www
firebase deploy
```

Speed ke liye ek aur cheez: aapki file abhi ek hi 99KB ki HTML file hai
(sab CSS/JS inline) — ye chhota hai isliye already fast load hoga; alag
se koi bada optimization abhi zaroori nahi.

**Note:** APK ke andar app khud bundled hai (files phone par hi hain), to
uske "load time" par Hosting ka koi asar nahi padta — sirf Firebase
Auth/Firestore/YouTube API calls hi network use karte hain, jo already
Google ke fast global servers par hain.

---

## Kya main abhi kar sakta hoon vs aapko khud karna hoga

| Kaam | Status |
|---|---|
| Capacitor project files (package.json, config) | ✅ Maine bana diye |
| `npm install`, `cap add android`, Gradle build | ❌ Aapke computer par (SDK/internet chahiye) |
| Signed release APK | ❌ Aapko keystore banakar sign karna hoga |
| Native Google Sign-In plugin wiring | Bata dein to main code likh doon, install/build aap karenge |

Chahen to bataiye — main Google Sign-In wala native plugin ka poora code
bhi likh doon (option 2), taaki APK me Google login bhi asli me kaam kare.
